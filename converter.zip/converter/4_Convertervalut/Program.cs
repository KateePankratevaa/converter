﻿using System.Xml;

XmlDocument doc = new XmlDocument();
doc.Load("students.xml");

var students = doc.DocumentElement;

WriteNode(students);

/// обход всех узлов в и вывод их имен
void WriteNode (XmlNode node)
{
    // пограничный случай: узел не имеет потомков (текст)
    if (!node.HasChildNodes)
    {
        return;
    }

    Console.WriteLine(node.Name);

    foreach (XmlNode child in node.ChildNodes)
    {
        WriteNode(child);
    }
}

