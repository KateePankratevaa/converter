﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF_Convertervalut.Model;

namespace WPF_Convertervalut.Data
{
    public static class ValuteLoader
    {
        /// <summary>
        /// Получает список валют из текста XML
        /// </summary>
        /// <param name="XMLText">Строка с информацией о валютах в формате XML</param>
        /// <returns>Список валют</returns>
        public static List<Valute> LoadValutes (string XMLText)
        {
            return XMLText;
        }
    }
}
