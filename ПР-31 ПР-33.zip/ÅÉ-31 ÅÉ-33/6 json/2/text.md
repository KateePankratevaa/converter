# Умный дом

Реадизуем программу для взаимодействия с api http://smartroom.ectsserver.edu

Программа должна позволять следующее:
- получение информации о состоянии комнаты (статус всех устройств);
- изменение статуса освещения (мощность, цвет);
- изменение параметров кондиционера (включение и выключение, установка температуры);
- взаимодействие с телевизором (включение и выключение, выбор канала, громкость);
- взаимодействие с музыкальным проирывателем (включение и выключение, выбор композиции из списка, добавление композиции в библиотеку);

## 1. Изучение функций api

Изучите функции api с помощью предоставленной документации и swagger. Многие функции имеют упрощенную реализацию, однако, учтите следующее:
- метод запроса (в запросах есть GET или POST);
- путь до запроса;
- параметры запроса (если есть);
- тело запроса (если есть);
- возвращаемые значения и поведение;

## 2. Создание проекта WPF

### 2.1 Создание проекта и настройка пакетов

Создайте проект WPF (.Net 6+).

С помощью диспетчера пакетов NuGet установите пакет `MaterialDesignThemes`.
После установки изучите документацию для данного пакета:
https://github.com/MaterialDesignInXAML/MaterialDesignInXamlToolkit
И краткое руководство для старта:
https://github.com/MaterialDesignInXAML/MaterialDesignInXamlToolkit/wiki/Getting-Started

Добавьте в `app.xaml` пространство имен:
```xml
xmlns:materialDesign="http://materialdesigninxaml.net/winfx/xaml/themes"
```

Добавьте строки:
```xml
<Application.Resources>
    <ResourceDictionary>
        <ResourceDictionary.MergedDictionaries>
            <materialDesign:BundledTheme BaseTheme="Dark" PrimaryColor="Indigo" SecondaryColor="Indigo" />
            <ResourceDictionary
                Source="pack://application:,,,/MaterialDesignThemes.Wpf;component/Themes/MaterialDesignTheme.Defaults.xaml" 	   />
        </ResourceDictionary.MergedDictionaries>
    </ResourceDictionary>
</Application.Resources>
```

Установим базовой темой темную (`Dark`) в качестве основного и дополнительных цветов выберем `Indigo`.

### 2.2 Верстка основного окна

Создайте в решении каталог `Views`. Перенесите в данный каталог `MainWindow.xaml` и запустите проект.

Вы увидете сообщение об ошибке, где будет написано, что ресурс `MainWindow.xaml` не найден:
```
System.IO.IOException: "Не удается найти ресурс "mainwindow.xaml"."
```

Измените в файле `app.xaml` значение свойства `StartupUri`:
```xml
StartupUri="Views/MainWindow.xaml"
```
Запустите приложение и убедитесь, что все работает.

Добавьте в свойства `MainWindow` строки:
```xml
<Window ...
	...
        xmlns:materialDesign="http://materialdesigninxaml.net/winfx/xaml/themes"
        Background="{DynamicResource MaterialDesignDarkBackground}"
        TextElement.Foreground="{DynamicResource MaterialDesignDarkForeground}"
        TextElement.FontFamily="{DynamicResource MaterialDesignFont}"
        TextElement.FontSize="20"
        TextElement.FontWeight="Light"
        Title="Умная комната" Height="600" Width="1000"
>
```
Для задания стилей Material Design элеменатм мы используем `Style = {DynamicResource ИМЯ_СТИЛЯ}`.
С помощью `TextElement.СВОЙСТВО` вы можете изменить параметры для дочерних элементов, содержащих текст.

Опишем корневой компоновочный элемент в окне:
```xml
<DockPanel Margin="5">

</DockPanel>
```

Добавим в него `TextBlock` и `WrapPanel`:
```xml
<TextBlock DockPanel.Dock="Top"
           Text="Умный дом"
           Style="{DynamicResource MaterialDesignHeadline3TextBlock}" Margin="0 0 0 10" />
<WrapPanel>

</WrapPanel>
```

Внутри `WrapPanel` разместим `Card` (из Material Design):
```xml
<WrapPanel>
    <materialDesign:Card Margin="10">

    </materialDesign:Card>
</WrapPanel>
```

Зададим внутри карточки разметку:
```xml
<Grid Width="400" Margin="8">
    <Grid.RowDefinitions>
        <RowDefinition Height="auto" />
        <RowDefinition />
        <RowDefinition Height="auto" />
    </Grid.RowDefinitions>
    <TextBlock Text="Освещение" HorizontalAlignment="Center" FontWeight="Normal" FontSize="30" />
    <TextBlock Grid.Row="1">
        <LineBreak />
        Мощность: <Run Text="Выкл" /><LineBreak />
        Цвет: <Run Text="Обычный" /><LineBreak />
    </TextBlock>
    <Button Grid.Row="2" FontSize="20" Height="35" HorizontalAlignment="Center" Content="Изменить" />
</Grid>
```

Примерный результат:
![](1.png)

Самостоятельно сверстайте еще 3 карточки (в качестве значений используйте просто строки-заглушки):
![](2.pnG)

### 2.3 Добавление моделей

Создайте в проекте папку `Models`. Обратитесь к методу api, который вернет полный статус комнаты и *скопируйте json-текст*.

В папке `Models` создайте класс `Room`. В Visual Studio найдите и используйте следующий пункт меню:
![](3.png)

Будут добавлены следующие классы:
```cs
public class Rootobject
{
    public Tv tv { get; set; }
    public Sound sound { get; set; }
    public Conditioner conditioner { get; set; }
    public Light light { get; set; }
}

public class Tv
{
    public int channel { get; set; }
    public int volume { get; set; }
    public bool on { get; set; }
}

public class Sound
{
    public int volume { get; set; }
    public bool isPlaying { get; set; }
    public string current { get; set; }
}

public class Conditioner
{
    public int temperature { get; set; }
    public float roomTemperature { get; set; }
    public bool on { get; set; }
}

public class Light
{
    public int status { get; set; }
    public int color { get; set; }
}
```

Переименуйте `Rootobject` в `Room` (при необходимости удалите строки пустого `Room`).

С помощью меню "Быстрые действия и рефакторинг" вынесите остальные классы в отдельные файлы:
![](4.png)

Измените регистр свойств, чтобы код соответствовал принятым в C# соглашениям. Пример измененного кода для `Room`:
```cs
public class Room
{
    public Tv Tv { get; set; }
    public Sound Sound { get; set; }
    public Conditioner Conditioner { get; set; }
    public Light Light { get; set; }
}
```

### 2.4 Добавление конфигурации

Вынесем url для удобства работы и настроики приложения в файл конфигурации.

Добавьте в проект файл конфигурации `app.config`. Для этого нажмите ПКМ по проекту, выберите пункт "Добавить->Создать элемент". В появившемся окне выберите категорию "Общие" и "Файл конфигурации приложения":
![](5.png)

Пропишите в созданном файле следующее:
```xml
<?xml version="1.0" encoding="utf-8" ?>
<configuration>
	<appSettings>
		<add key="baseUrl" value="http://ectsserver.edu:3000/api/" />
	</appSettings>
</configuration>
```

### 2.5 Получение информации о статусе комнаты

Пропишите в конструкторе `MainWindow` следующее:
```cs
private readonly string baseUrl;

public MainWindow()
{
    InitializeComponent();
    baseUrl =
        ConfigurationManager.AppSettings["baseUrl"] ??
        throw new ApplicationException("Invalid configuration: baseUrl is not specified");
}
```

Это позволит загрузить строку `baseUrl` из файла конфигурации и сохранить значение в скрытое поле типа `string`.

Далее, добавьте для `MainWindow` обработчик события `Loaded` и сделайте его асинхронным:
```xml
Loaded="loadRoomStatus"
```
```cs
private async void loadRoomStatus(object sender, RoutedEventArgs e)
{

}
```

Добавьте метод:
```cs
private async Task<Room> loadRoomAsync()
{

}
```

Создайте публичное свойство:
```cs
public Room RoomInfo { get; set; }
```

И напишите код:
```cs
private async Task<Room?> loadRoomAsync()
{
    using (HttpClient client = new())
    {
        return await client.GetFromJsonAsync<Room>(baseUrl + "Room/Status");
    }
}
```

```cs
private async void loadRoomStatus(object sender, RoutedEventArgs e)
{
    Room? room = await loadRoomAsync();
    if (room is not null)
    {
        RoomInfo = room;
        // обновим контекст привязки окна
        DataContext = null;
        DataContext = RoomInfo;
    }
}
```

Мы задаем при загрузке в качестве контекста привязки экземпляр `Room`. Выполним привязку его свойств для лампочки:
```xml
...
<materialDesign:Card Margin="10">
    <Grid Width="400" Margin="8">
        <Grid.RowDefinitions>
            <RowDefinition Height="auto" />
            <RowDefinition />
            <RowDefinition Height="auto" />
        </Grid.RowDefinitions>
        <TextBlock Text="Освещение" HorizontalAlignment="Center" FontWeight="Normal" FontSize="30" />
        <TextBlock Grid.Row="1">
            <LineBreak />
            Мощность: <Run Text="{Binding Light.Status}" /><LineBreak />
            Цвет: <Run Text="{Binding Light.Color}"  /><LineBreak />
        </TextBlock>
        <Button Grid.Row="2" FontSize="20" Height="35" HorizontalAlignment="Center" Content="Изменить" />
    </Grid>
</materialDesign:Card>
...
```

Запустите приложение. Вы получите примерно такой результат:
![](6.png)

Обновите значения через api и перезапустите приложение. Убедитесь, что значения будут изменены.

Внесите в класс `Light` изменения, добавив два read only свойства:
```cs
public class Light
{
    public int Status { get; set; }
    public int Color { get; set; }

    public string StatusString
    {
        get
        {
            return Status switch
            {
                0 => "Выключено",
                1 => "Слабое освещение",
                2 => "Среднее освещение",
                3 => "Полное освещение",
                _ => "Неизвестно"
            };
        }
    }

    public string ColorString
    {
        get
        {
            return Color switch
            {
                0 => "Обычный",
                1 => "Горячий",
                2 => "Холодный",
                _ => "Неизвестно"
            };
        }
    }
}
```

Или, используя `=>`:
```cs
public class Light
{
    public int Status { get; set; }
    public int Color { get; set; }

    public string StatusString => Status switch
    {
        0 => "Выключено",
        1 => "Слабое освещение",
        2 => "Среднее освещение",
        3 => "Полное освещение",
        _ => "Неизвестно"
    };

    public string ColorString => Color switch
    {
        0 => "Обычный",
        1 => "Горячий",
        2 => "Холодный",
        _ => "Неизвестно"
    };
}
```

Чтобы свойства игнорировались при сериализации `Json` мы можем добавить аттрибут `JsonIgnore`. Окончательный вариант:
```cs
public class Light
{
    public int Status { get; set; }
    public int Color { get; set; }

    [JsonIgnore]
    public string StatusString => Status switch
    {
        0 => "Выключено",
        1 => "Слабое освещение",
        2 => "Среднее освещение",
        3 => "Полное освещение",
        _ => "Неизвестно"
    };

    [JsonIgnore]
    public string ColorString => Color switch
    {
        0 => "Обычный",
        1 => "Горячий",
        2 => "Холодный",
        _ => "Неизвестно"
    };
}
```

Изменим привязку:
```cs
Мощность: <Run Text="{Binding Light.StatusString, Mode=OneWay}" /><LineBreak />
Цвет: <Run Text="{Binding Light.ColorString,Mode=OneWay}"  /><LineBreak />
```

Запустите приложение и убедитесь в работоспособности:
![](7.png)


Самостоятельно добейтесь корректного вывода остальных значений. Где это необходимо добавьте дополнительные свойства в классы или используйте конвертеры (`IValueConverter`).
![](8.png)

### 2.6 Добавление таймера

Добавьте в `MainWindow` поле типа `DispatcherTimer`:
```cs
private DispatcherTimer timer = new DispatcherTimer
{
    Interval = TimeSpan.FromSeconds(5)
};
```

Добавьте в конструкторе обработчик:
```cs
public MainWindow()
{
    InitializeComponent();
    baseUrl =
        ConfigurationManager.AppSettings["baseUrl"] ??
        throw new ApplicationException("Invalid configuration: baseUrl is not specified");

    timer.Tick += (sender, e) =>
    {
        loadRoomStatus(sender!, null!);
    };
}
```

Запустите и убедитесь, что теперь значения обновляются каждые 5 секунд.


### 2.7 Окно освещения

Создайте в папке `Views` новое окно `LightsWindow`. Реализуйте переход на это окно по нажатию на кнопку в карточке "Освещение".

Самостоятельно сверстайте следующее окно:
![](9.pNg)

Реализуем изменение статуса по нажатию на кнопку. Сперва выполним заполнение ComboBox с помощью свойства `ItemsSource`:
```cs
public partial class LightsWindow : Window
{
    class Item
    {
        public int Code { get; set; }
        public string Description { get; set; } = string.Empty;
    }


    public LightsWindow()
    {
        InitializeComponent();
        statusComboBox.ItemsSource = new Item[]
        {
            new Item { Code = 0, Description = "Выключено" },
            new Item { Code = 1, Description = "Слабое освещение" },
            new Item { Code = 2, Description = "Среднее освещение" },
            new Item { Code = 3, Description = "Полное освещение" },
        };
        statusComboBox.DisplayMemberPath = "Description";
        statusComboBox.SelectedIndex = 0;
    }
}
```

Прокиньте через конструктор класса `LightsWindow` значение `baseUrl` и сохраните его в скрытом поле типа `string`:
```cs
private readonly string baseUrl;
```
```cs
public LightsWindow(string baseUrl)
{
    this.baseUrl = baseUrl;
    InitializeComponent();
    statusComboBox.ItemsSource = new Item[]
    {
        new Item { Code = 0, Description = "Выключено" },
        new Item { Code = 1, Description = "Слабое освещение" },
        new Item { Code = 2, Description = "Среднее освещение" },
        new Item { Code = 3, Description = "Полное освещение" },
    };
    statusComboBox.DisplayMemberPath = "Description";
    statusComboBox.SelectedIndex = 0;
}
```
Измените код, который выполняет переход с `MainWindow` на `LightsWindow`, передав в конструктор параметр.

Далее, добавим обработчик события нажатия на кнопку:
```xml
<Button Click="updateStatus" ...
```
```cs
private async void updateStatus(object sender, RoutedEventArgs e)
{
    var item = (statusComboBox.SelectedItem as Item);

    if (item is null)
    {
        return;
    }

    int id = item.Code;

    using (HttpClient client = new())
    {
        var response = await client.GetAsync(baseUrl + $"Room/Light/PowerOn/{id}");
        if (response.IsSuccessStatusCode)
        {
            MessageBox.Show("Обновлено.");
        }
        else if (response.StatusCode == HttpStatusCode.BadRequest)
        {
            MessageBox.Show("Не удалось обновить. Передано некорректное значение");
        }
        else
        {
            MessageBox.Show("Не удалось обновить");
        }
    }
}
```

Запустите и проверьте работоспособность.

**Самостоятельно**:
- реализуйте изменение цвета освещения;
- при получение ответа от сервера, в случае, если все успешно, вместо демонстрации `MessageBox` обновите в окне текстовые поля ("текущее состояние"). В случае ошибки также выводите сообщение об ошибке (кастомизируйте его, добавив иконку и заголовок);
- обновляйте статус освещения по таймеру или добавьте отдельную кнопку обновления, которая будет загружать статус.

Для загрузки информации об освещении используйте соответствующий метод api.

### 2.8 Кондиционер и телевизор

По аналогии с предыдущим окном реализуйте самостоятельно функциональность для кондиционера и телевизора. Учтите, что для телевизора реализован `Bad Request` при попытке изменить канал или громкость, если он выключен.

