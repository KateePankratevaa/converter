﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeroVsMonster.Classes
{
    /// <summary>
    /// Базовый класс для Hero и Monster
    /// </summary>
    public abstract class Actor
    {
        protected int MaxHp;
        protected int Hp;
        protected int Potions;
        /// <summary>
        /// true, если мертв
        /// </summary>
        public bool IsDead { get; protected set; }
        /// <summary>
        /// Имя персонажа
        /// </summary>
        public string Name { get; protected set; }
        /// <summary>
        /// Урон персонажа
        /// </summary>
        public int Damage { get; protected set; }

        public int Health 
        { 
            get
            {
                return Hp;
            }
        }
        public int MaximumHealth
        {
            get
            {
                return MaxHp;
            }
        }

        /// <summary>
        /// Конструктор класса Actor
        /// </summary>
        /// <param name="name">Имя персонажа</param>
        /// <param name="maximumHp">Максимальное здоровье</param>
        /// <param name="damage">Наносимый урон</param>
        public Actor(string name, int maximumHp, int damage)
        {
            // уже реализовано
            this.Name = name;
            this.Hp = this.MaxHp = maximumHp;
            this.Damage = damage;
            Potions = 0;
        }

        /// <summary>
        /// Позволяет получить урон и уменьшить здоровье.
        /// </summary>
        /// <param name="dmg">Полученный урон</param>
        public void GetDamage(int dmg)
        {
            throw new NotImplementedException("Не реализовано");
        }

        /// <summary>
        /// Позволяет использовать зелье, чтобы восстановить 1/5 от 
        /// максимальной жизни. Не может быть бесполезным при низком максимальном
        /// здоровье. Не может сделать здоровье больше, чем максимальное.
        /// Зелье при использовании будет потрачено.
        /// </summary>
        public void UsePotion()
        {
            throw new NotImplementedException("Не реализовано");
        }


        /// <summary>
        /// Боевой крик персонажа
        /// </summary>
        /// <returns>Возвращает строку, соответствующую боевому крику</returns>
        public virtual string Roar()
        {
            return "Hello, World!";
        }
    }
}
